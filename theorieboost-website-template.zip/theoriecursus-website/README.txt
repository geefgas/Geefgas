THEORIEBOOST WEBSITE TEMPLATE

Wat is dit?
- Een simpele, snelle website (HTML/CSS/JS) om jouw theoriecursus te verkopen.
- Je hoeft alleen teksten/prijs/knoppen aan te passen en te koppelen aan een betaalplatform.

Snel live zetten (makkelijk):
1) Netlify (drag & drop)
   - Ga naar netlify.com > Add new site > Deploy manually
   - Sleep de hele map naar Netlify

2) Vercel / Cloudflare Pages
   - Upload als static site

Betaling + levering (aanrader):
- Gumroad of Lemon Squeezy:
  - Maak product aan
  - Zet de "Koop toegang" link in index.html bij de knop
  - Stel 'redirect after purchase' in naar bedankt.html

Aanpassen:
- Zoek in index.html naar:
  - TheorieBoost (naam)
  - €29 (prijs)
  - gumroad.com (kooplink)
  - jij@jouwdomein.nl (support e-mail)

Let op:
- Gebruik geen echte CBR-examenvragen, screenshots of letterlijk gekopieerde teksten uit boeken.
- Zet altijd duidelijk dat je niet verbonden bent aan het CBR.

Succes!